export default {
    todos: [
        {
            id: 1,
            text: '111',
        },
        {
            id: 2,
            text: '222',
        },
        {
            id: 3,
            text: '333',
        },
    ],
};
