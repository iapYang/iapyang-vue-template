export default {
    todoCount: state => state.todos.length,
};
